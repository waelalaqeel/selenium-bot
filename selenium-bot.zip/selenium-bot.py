
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

def run_bot():
    # Initialize WebDriver
    service = Service()
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")  # Run in headless mode
    driver = webdriver.Chrome(service=service, options=options)

    try:
        driver.get("https://example.com")
        print("Page title is:", driver.title)

        # Example interaction
        time.sleep(2)  # Wait for page to load
        print("URL:", driver.current_url)

    finally:
        driver.quit()

if __name__ == "__main__":
    run_bot()
